INSERT IGNORE INTO `#__cf_filtertypes` (`id`, `type`) VALUES
(8, 'range_dates');