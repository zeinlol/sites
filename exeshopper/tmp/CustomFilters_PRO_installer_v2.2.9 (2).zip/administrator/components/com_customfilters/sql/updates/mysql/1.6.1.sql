INSERT IGNORE INTO `#__cf_filtertypes` (`id`, `type`) VALUES
(5, 'range_inputs'),
(6, 'range_slider');